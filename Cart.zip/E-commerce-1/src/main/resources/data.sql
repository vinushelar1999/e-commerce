CREATE TABLE Persons (
    PersonID int,
    LastName varchar(255),
    FirstName varchar(255),
    Address varchar(255),
    City varchar(255)
);

CREATE TABLE Location (
    LocationID int,
    Name varchar(255),
    City varchar(255)
);

INSERT INTO Category (categoryID, CategoryName)
VALUES (1, 'Fashion'), (2, 'Electronics'), (3, 'Books'), (4, 'Groceries'), (5, 'Medicines');

INSERT INTO Role (Role)
VALUES ('CONSUMER'), ('SELLER');

INSERT INTO User (username, password)
VALUES ('jack', 'pass_word'), ('bob', 'pass_word''), ('apple', 'pass_word'), ('glaxo', 'pass_word');

INSERT INTO Cart (totalAmount, userId)
VALUES (20, 1), (0, 2);

INSERT INTO UserRole (userId, role)
VALUES (1, 1), (2, 1), (3, 2), (4, 2);

INSERT INTO Product (price, productName, categoryId, sellerId)
VALUES (29190, 'Apple iPad 10.2 8th Gen WiFi iOS Tablet', 2, 3), ('SELLER'),
(10, 'Crocin pain relief tablet', 5, 4);

INSERT INTO CartProduct (cartId, productId, quantity)
VALUES (1, 2, 2);